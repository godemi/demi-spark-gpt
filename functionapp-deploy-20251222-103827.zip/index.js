"use strict";
/**
 * Main entry point for Azure Functions
 *
 * IMPORTANT: All function registrations must happen at the top level
 * with no other code execution before them. This ensures Azure Functions
 * can properly detect and register all HTTP triggers.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
// Import Azure Functions app instance
const functions_1 = require("@azure/functions");
Object.defineProperty(exports, "app", { enumerable: true, get: function () { return functions_1.app; } });
// Register all HTTP functions - these MUST be imported first
// and executed synchronously during module load
require("./functions/httpGetInfo");
require("./functions/httpGetModels");
require("./functions/httpGetStatus");
require("./functions/httpPostChatCompletions");
require("./functions/httpPostCompletions");
require("./functions/httpPostImageGenerate");
//# sourceMappingURL=index.js.map