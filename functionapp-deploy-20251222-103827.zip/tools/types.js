"use strict";
/**
 * Tool/Function Calling Types
 *
 * Types for OpenAI-compatible tool calling functionality
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolCallSchema = exports.ToolDefinitionSchema = void 0;
// Re-export from chatCompletionTypes for convenience
var chatCompletionTypes_1 = require("../models/chatCompletionTypes");
Object.defineProperty(exports, "ToolDefinitionSchema", { enumerable: true, get: function () { return chatCompletionTypes_1.ToolDefinitionSchema; } });
Object.defineProperty(exports, "ToolCallSchema", { enumerable: true, get: function () { return chatCompletionTypes_1.ToolCallSchema; } });
//# sourceMappingURL=types.js.map