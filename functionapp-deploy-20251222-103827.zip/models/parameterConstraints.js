"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ParameterConstraintSchema = exports.PARAMETER_CONSTRAINTS = void 0;
const zod_1 = require("zod");
/**
 * Defines constraints for all supported Azure OpenAI API parameters
 * Used for parameter validation and documentation generation
 *
 * @constant
 * @type {Record<string, ParameterConstraint>}
 */
exports.PARAMETER_CONSTRAINTS = {
    best_of: {
        min: 2,
        max: null,
        type: "int",
        description: "Number of server-side completion alternatives to generate",
    },
    frequency_penalty: {
        min: -2.0,
        max: 2.0,
        type: "float",
        description: "Penalty for token frequency in generated text",
    },
    max_tokens: {
        min: 1,
        max: 32768,
        type: "int",
        description: "Maximum number of tokens to generate",
    },
    min_tokens: {
        min: 1,
        max: 32768,
        type: "int",
        description: "Minimum number of tokens to generate",
    },
    n: {
        min: 1,
        max: null,
        type: "int",
        description: "Number of completions to generate",
    },
    presence_penalty: {
        min: -2.0,
        max: 2.0,
        type: "float",
        description: "Penalty for token presence in generated text",
    },
    temperature: {
        min: 0.0,
        max: 2.0,
        type: "float",
        description: "Sampling temperature for token generation",
    },
    top_p: {
        min: 0.0,
        max: 1.0,
        type: "float",
        description: "Nucleus sampling probability threshold",
    },
    history_window: {
        min: 1,
        max: 100,
        type: "int",
        description: "Maximum number of history messages to include",
    },
    max_history_tokens: {
        min: 32,
        max: 32768,
        type: "int",
        description: "Token budget for history inclusion when using token_budget strategy",
    },
};
/**
 * Zod schema for runtime validation of parameter constraints
 * Ensures all constraints follow the required structure
 *
 * @constant
 * @type {z.ZodObject}
 */
exports.ParameterConstraintSchema = zod_1.z.object({
    min: zod_1.z.number(),
    max: zod_1.z.number().nullable(),
    type: zod_1.z.enum(["int", "float"]),
    description: zod_1.z.string(),
});
//# sourceMappingURL=parameterConstraints.js.map