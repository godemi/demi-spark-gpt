"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureChatGPTRequestParameterSchema = exports.OFFICIAL_AZURE_OPENAI_CHATGPT_PARAMETERS = exports.DEFAULT_SPARK_GPT_PARAMETERS = exports.SparkGPTProcessedParametersSchema = exports.SparkGPTInputParametersSchema = exports.PrePromptTypeSchema = exports.VALID_PRE_PROMPT_ROLES = exports.CustomPrePromptTypeSchema = exports.VariableTypeSchema = exports.HistoryStrategySchema = exports.ChatMessageSchema = exports.ChatRoleSchema = void 0;
const zod_1 = require("zod");
const parameterConstraints_1 = require("./parameterConstraints");
/**
 * Type Definitions for SparkGPT API
 *
 * This file contains all type definitions and schemas used throughout the application.
 * It uses Zod for runtime type validation and TypeScript for static typing.
 */
const constrainedNumber = (name) => {
    const { min, max } = parameterConstraints_1.PARAMETER_CONSTRAINTS[name];
    let schema = zod_1.z.coerce.number().min(min, { message: `${name} must be >= ${min}` });
    if (max !== null) {
        schema = schema.max(max, { message: `${name} must be <= ${max}` });
    }
    return schema;
};
exports.ChatRoleSchema = zod_1.z.enum(["system", "user", "assistant"]);
exports.ChatMessageSchema = zod_1.z.object({
    role: exports.ChatRoleSchema,
    content: zod_1.z.string(),
    created_at: zod_1.z.string().optional(),
    id: zod_1.z.string().optional(),
});
exports.HistoryStrategySchema = zod_1.z.enum(["last_n", "token_budget", "all"]);
/**
 * Variable Type Definitions
 * @description Represents dynamic variables that can be injected into prompts
 */
exports.VariableTypeSchema = zod_1.z.object({
    name: zod_1.z.string(), // Identifier for the variable
    description: zod_1.z.string(), // Human-readable description
    value: zod_1.z.string(), // The actual value to be used
    type: zod_1.z.enum([
        // Supported data types
        "string",
        "iso-8601",
        "integer",
        "float",
        "boolean",
        "timestamp",
    ]),
});
/**
 * Custom Pre-Prompt Type Definitions
 * @description Defines structure for user-provided pre-prompts
 */
exports.CustomPrePromptTypeSchema = zod_1.z.object({
    name: zod_1.z.string(), // Identifier for the pre-prompt
    description: zod_1.z.string(), // Purpose/description of the pre-prompt
    role: zod_1.z.enum([
        // Role in the conversation
        "system", // System-level instructions
        "user", // User context/preferences
        "assistant", // Assistant behavior modifications
    ]),
    text: zod_1.z.string(), // The actual pre-prompt content
});
/**
 * Valid Pre-Prompt Roles
 * @description Defines allowable roles for pre-prompts
 */
exports.VALID_PRE_PROMPT_ROLES = new Set([
    "system_pre_prompts",
    "user_pre_prompts",
    "assistant_pre_prompts",
]);
/**
 * PrePromptType: Represents a structured pre-prompt.
 */
exports.PrePromptTypeSchema = zod_1.z.object({
    role: zod_1.z.enum(["system", "user", "assistant"]).optional(),
    type: zod_1.z.string(),
    text: zod_1.z.string(),
});
/**
 * SparkGPTInputParametersType: Represents the input parameters for a SparkGPT request.
 */
exports.SparkGPTInputParametersSchema = zod_1.z.object({
    // Main prompt(s)
    prompt: zod_1.z.union([zod_1.z.string(), zod_1.z.array(zod_1.z.string())]),
    // Optional streaming flag
    stream: zod_1.z.boolean().optional(),
    // Required parameters
    temperature: constrainedNumber("temperature"),
    max_tokens: constrainedNumber("max_tokens"),
    fallback_result_language: zod_1.z.enum(["en", "de", "fr", "es"]),
    // Optional parameters (added best_of property)
    best_of: constrainedNumber("best_of").optional(),
    frequency_penalty: constrainedNumber("frequency_penalty").optional(),
    logit_bias: zod_1.z.record(zod_1.z.number()).optional(),
    min_tokens: constrainedNumber("min_tokens").optional(),
    n: constrainedNumber("n").optional(),
    presence_penalty: constrainedNumber("presence_penalty").optional(),
    stop: zod_1.z.union([zod_1.z.string(), zod_1.z.array(zod_1.z.string())]).optional(),
    suffix: zod_1.z.string().optional(),
    // System pre-prompt configurations (required)
    system_pre_prompts_global: zod_1.z.boolean(),
    system_pre_prompts_generate_min_tokens: zod_1.z.boolean(),
    system_pre_prompts_explain_technical_terms: zod_1.z.boolean(),
    system_pre_prompts_non_expert_mode: zod_1.z.boolean(),
    system_pre_prompts_brief_response: zod_1.z.boolean(),
    system_pre_prompts_add_emoticons: zod_1.z.boolean(),
    system_pre_prompts_format_as_markdown: zod_1.z.boolean(),
    // Other required parameters
    top_p: constrainedNumber("top_p"),
    // Optional user identifier
    user: zod_1.z.string().optional(),
    // Optional lists
    variables: zod_1.z.array(exports.VariableTypeSchema).optional(),
    custom_pre_prompts: zod_1.z.array(exports.CustomPrePromptTypeSchema).optional(),
    // Chat history controls
    system_prompt: zod_1.z.union([zod_1.z.string(), zod_1.z.array(zod_1.z.string())]).optional(),
    history: zod_1.z.array(exports.ChatMessageSchema).optional(),
    history_window: constrainedNumber("history_window").optional(),
    history_strategy: exports.HistoryStrategySchema.optional(),
    max_history_tokens: constrainedNumber("max_history_tokens").optional(),
    // New parameter for overwriting system pre-prompts
    overwrite_system_pre_prompts: zod_1.z
        .array(zod_1.z.object({
        name: zod_1.z.enum([
            "system_pre_prompts_global",
            "system_pre_prompts_explain_technical_terms",
            "system_pre_prompts_non_expert_mode",
            "system_pre_prompts_brief_response",
            "system_pre_prompts_add_emoticons",
            "system_pre_prompts_format_as_markdown",
        ]),
        prompt: zod_1.z.string(),
    }))
        .optional(),
});
/**
 * SparkGPTProcessedParametersType: Extends the input parameters with pre-prompt arrays.
 */
exports.SparkGPTProcessedParametersSchema = exports.SparkGPTInputParametersSchema.extend({
    pre_prompts: zod_1.z.array(exports.PrePromptTypeSchema),
});
/**
 * DEFAULT_SPARK_GPT_PARAMETERS: Default values for SparkGPT parameters.
 */
exports.DEFAULT_SPARK_GPT_PARAMETERS = {
    prompt: "",
    stream: false,
    temperature: 0.7,
    max_tokens: 1600,
    fallback_result_language: "en",
    best_of: undefined,
    frequency_penalty: undefined,
    logit_bias: undefined,
    min_tokens: undefined,
    n: undefined,
    presence_penalty: undefined,
    stop: undefined,
    suffix: undefined,
    system_pre_prompts_global: true,
    system_pre_prompts_generate_min_tokens: false,
    system_pre_prompts_explain_technical_terms: false,
    system_pre_prompts_non_expert_mode: false,
    system_pre_prompts_brief_response: false,
    system_pre_prompts_add_emoticons: false,
    system_pre_prompts_format_as_markdown: false,
    top_p: 0.95,
    user: undefined,
    system_prompt: undefined,
    history: [],
    history_window: 3,
    history_strategy: "last_n",
    max_history_tokens: undefined,
    variables: [],
    custom_pre_prompts: [],
    pre_prompts: [],
    overwrite_system_pre_prompts: [],
};
/**
 * OFFICIAL_AZURE_OPENAI_CHATGPT_PARAMETERS: List of official parameters.
 */
exports.OFFICIAL_AZURE_OPENAI_CHATGPT_PARAMETERS = [
    "temperature",
    "top_p",
    "max_tokens",
    "best_of",
    "frequency_penalty",
    "presence_penalty",
    "logit_bias",
    "stop",
    "stream",
    "suffix",
    "n",
    "user",
];
/**
 * AzureChatGPTRequestParameterType: Defines parameters for an Azure OpenAI GPT request.
 */
exports.AzureChatGPTRequestParameterSchema = zod_1.z.object({
    messages: zod_1.z.array(zod_1.z.record(zod_1.z.string())),
    fallback_result_language: zod_1.z.enum(["en", "de", "fr", "es"]).optional(),
    temperature: zod_1.z.number(),
    top_p: zod_1.z.number(),
    max_tokens: zod_1.z.number(),
    min_tokens: zod_1.z.number().optional(),
    n: zod_1.z.number().optional(),
    best_of: zod_1.z.number().optional(),
    frequency_penalty: zod_1.z.number().optional(),
    presence_penalty: zod_1.z.number().optional(),
    logit_bias: zod_1.z.record(zod_1.z.number()).optional(),
    stop: zod_1.z.union([zod_1.z.string(), zod_1.z.array(zod_1.z.string())]).optional(),
    stream: zod_1.z.boolean().optional(),
    suffix: zod_1.z.string().optional(),
    user: zod_1.z.string().optional(),
});
//# sourceMappingURL=types.js.map