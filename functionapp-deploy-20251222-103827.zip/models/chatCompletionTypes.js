"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinalChunkSchema = exports.SSEChunkSchema = exports.ChatCompletionResponseSchema = exports.UsageSchema = exports.ChatCompletionChoiceSchema = exports.ChatCompletionRequestSchema = exports.ReasoningEffortSchema = exports.TaskProfileSchema = exports.ToolChoiceSchema = exports.ResponseFormatSchema = exports.ImageParamsSchema = exports.ChatMessageSchema = exports.ContentPartSchema = exports.ToolCallSchema = exports.ToolDefinitionSchema = exports.AttachmentSchema = void 0;
const zod_1 = require("zod");
/**
 * HALO Layer - OpenAI-Compatible Chat Completion Types
 *
 * This module defines the core request/response schemas for the HALO layer,
 * providing OpenAI-compatible API contracts with provider-specific extensions.
 */
/**
 * Attachment schema for input/output attachments (images, files)
 */
exports.AttachmentSchema = zod_1.z.object({
    type: zod_1.z.enum(["image", "file"]),
    mime_type: zod_1.z.string(),
    data: zod_1.z.string().optional(), // base64 encoded data
    url: zod_1.z.string().url().optional(), // URL reference
    filename: zod_1.z.string().optional(),
    alt: zod_1.z.string().optional(),
    size_bytes: zod_1.z.number().optional(),
}).refine((data) => data.data !== undefined || data.url !== undefined, {
    message: "Either 'data' or 'url' must be specified for attachment",
    path: ["data"],
});
/**
 * Tool definition schema for function calling
 */
exports.ToolDefinitionSchema = zod_1.z.object({
    type: zod_1.z.literal("function"),
    function: zod_1.z.object({
        name: zod_1.z.string(),
        description: zod_1.z.string().optional(),
        parameters: zod_1.z.record(zod_1.z.any()), // JSON Schema object
        strict: zod_1.z.boolean().optional(),
    }),
});
/**
 * Tool call schema (from model response)
 */
exports.ToolCallSchema = zod_1.z.object({
    id: zod_1.z.string(),
    type: zod_1.z.literal("function"),
    function: zod_1.z.object({
        name: zod_1.z.string(),
        arguments: zod_1.z.string(), // JSON string
    }),
});
/**
 * Content part for multimodal messages (text + image_url)
 */
exports.ContentPartSchema = zod_1.z.object({
    type: zod_1.z.enum(["text", "image_url"]),
    text: zod_1.z.string().optional(),
    image_url: zod_1.z
        .object({
        url: zod_1.z.string(),
        detail: zod_1.z.enum(["auto", "low", "high"]).optional(),
    })
        .optional(),
});
/**
 * Chat message schema with OpenAI-compatible format
 */
exports.ChatMessageSchema = zod_1.z.object({
    role: zod_1.z.enum(["system", "user", "assistant", "tool"]),
    content: zod_1.z.union([zod_1.z.string(), zod_1.z.array(exports.ContentPartSchema), zod_1.z.null()]).optional(),
    name: zod_1.z.string().optional(),
    tool_calls: zod_1.z.array(exports.ToolCallSchema).optional(),
    tool_call_id: zod_1.z.string().optional(),
    // HALO extension: attachments for easier API usage
    attachments: zod_1.z.array(exports.AttachmentSchema).optional(),
}).refine((data) => data.content !== undefined || data.tool_calls !== undefined || data.role === "tool", {
    message: "Message must have either content, tool_calls, or be a tool message",
    path: ["content"],
});
/**
 * Image generation parameters
 */
exports.ImageParamsSchema = zod_1.z.object({
    size: zod_1.z.enum(["256x256", "512x512", "1024x1024", "1792x1024", "1024x1792"]).optional(),
    quality: zod_1.z.enum(["standard", "hd"]).optional(),
    format: zod_1.z.enum(["url", "b64_json"]).optional(),
    n: zod_1.z.number().int().min(1).max(10).optional(),
    style: zod_1.z.enum(["vivid", "natural"]).optional(),
});
/**
 * Response format schema
 */
exports.ResponseFormatSchema = zod_1.z.union([
    zod_1.z.literal("text"),
    zod_1.z.literal("json"),
    zod_1.z.object({
        type: zod_1.z.literal("json_schema"),
        json_schema: zod_1.z.record(zod_1.z.any()),
    }),
]);
/**
 * Tool choice schema
 */
exports.ToolChoiceSchema = zod_1.z.union([
    zod_1.z.literal("auto"),
    zod_1.z.literal("none"),
    zod_1.z.object({
        type: zod_1.z.literal("function"),
        function: zod_1.z.object({
            name: zod_1.z.string(),
        }),
    }),
]);
/**
 * Task profile for automatic model selection
 */
exports.TaskProfileSchema = zod_1.z.enum([
    "fast",
    "balanced",
    "reasoning",
    "deep_reasoning",
    "creative",
    "cost_effective",
]);
/**
 * Reasoning effort levels for GPT-5 models
 */
exports.ReasoningEffortSchema = zod_1.z.enum(["none", "low", "medium", "high", "xhigh"]);
/**
 * Main chat completion request schema
 */
exports.ChatCompletionRequestSchema = zod_1.z.object({
    // Required fields
    api_version: zod_1.z.string(),
    model: zod_1.z.string().optional(), // Optional when task_profile is used
    messages: zod_1.z.array(exports.ChatMessageSchema).min(1),
    // Task-based model selection (alternative to direct model selection)
    task_profile: exports.TaskProfileSchema.optional(),
    // Provider routing
    provider: zod_1.z.enum(["azure-openai", "openai", "azure-ai-foundry"]).optional(),
    azure_deployment: zod_1.z.string().optional(),
    azure_endpoint: zod_1.z.string().url().optional(),
    // Generation parameters
    stream: zod_1.z.boolean().default(false),
    temperature: zod_1.z.number().min(0).max(2).optional(),
    top_p: zod_1.z.number().min(0).max(1).optional(),
    max_tokens: zod_1.z.number().int().min(1).optional(),
    max_completion_tokens: zod_1.z.number().int().min(1).optional(),
    // Reasoning mode (o1/o3 models)
    reasoning_mode: zod_1.z.enum(["standard", "deep", "thinking"]).optional(),
    max_reasoning_tokens: zod_1.z.number().int().optional(),
    // Reasoning effort (GPT-5 models: gpt-5, gpt-5-mini, gpt-5-nano, gpt-5.2)
    reasoning_effort: exports.ReasoningEffortSchema.optional(),
    // Advanced parameters
    response_format: exports.ResponseFormatSchema.optional(),
    tools: zod_1.z.array(exports.ToolDefinitionSchema).optional(),
    tool_choice: exports.ToolChoiceSchema.optional(),
    seed: zod_1.z.number().int().optional(),
    stop: zod_1.z.union([zod_1.z.string(), zod_1.z.array(zod_1.z.string())]).optional(),
    presence_penalty: zod_1.z.number().min(-2).max(2).optional(),
    frequency_penalty: zod_1.z.number().min(-2).max(2).optional(),
    n: zod_1.z.number().int().min(1).max(128).optional(),
    logit_bias: zod_1.z.record(zod_1.z.number()).optional(),
    logprobs: zod_1.z.boolean().optional(),
    top_logprobs: zod_1.z.number().int().min(0).max(20).optional(),
    user: zod_1.z.string().optional(),
    // HALO-specific extensions
    mode: zod_1.z.enum(["chat", "image_generate", "multi"]).default("chat"),
    image_params: exports.ImageParamsSchema.optional(),
    system_guardrails_enabled: zod_1.z.boolean().default(false),
    guardrail_profile: zod_1.z.string().optional(),
}).refine((data) => data.model !== undefined || data.task_profile !== undefined, {
    message: "Either 'model' or 'task_profile' must be specified",
    path: ["model"], // Set path to model field for better error reporting
});
/**
 * Chat completion choice schema
 */
exports.ChatCompletionChoiceSchema = zod_1.z.object({
    index: zod_1.z.number(),
    message: exports.ChatMessageSchema,
    finish_reason: zod_1.z
        .enum(["stop", "length", "tool_calls", "content_filter", "function_call"])
        .nullable(),
    logprobs: zod_1.z.any().nullable().optional(),
});
/**
 * Usage statistics schema
 */
exports.UsageSchema = zod_1.z.object({
    prompt_tokens: zod_1.z.number(),
    completion_tokens: zod_1.z.number(),
    total_tokens: zod_1.z.number(),
    reasoning_tokens: zod_1.z.number().optional(),
});
/**
 * Chat completion response schema (OpenAI-compatible)
 */
exports.ChatCompletionResponseSchema = zod_1.z.object({
    id: zod_1.z.string(),
    object: zod_1.z.literal("chat.completion"),
    created: zod_1.z.number(),
    model: zod_1.z.string(),
    choices: zod_1.z.array(exports.ChatCompletionChoiceSchema),
    usage: exports.UsageSchema.optional(),
    // HALO extensions
    request_id: zod_1.z.string().optional(),
    provider: zod_1.z.string().optional(),
    latency_ms: zod_1.z.number().optional(),
    attachments: zod_1.z.array(exports.AttachmentSchema).optional(),
});
/**
 * SSE chunk schema for streaming responses
 */
exports.SSEChunkSchema = zod_1.z.object({
    id: zod_1.z.string(),
    object: zod_1.z.literal("chat.completion.chunk"),
    created: zod_1.z.number(),
    model: zod_1.z.string(),
    choices: zod_1.z.array(zod_1.z.object({
        index: zod_1.z.number(),
        delta: zod_1.z.object({
            role: zod_1.z.enum(["system", "user", "assistant", "tool"]).optional(),
            content: zod_1.z.string().nullable().optional(),
            tool_calls: zod_1.z.array(exports.ToolCallSchema).optional(),
        }),
        finish_reason: zod_1.z
            .enum(["stop", "length", "tool_calls", "content_filter"])
            .nullable()
            .optional(),
        logprobs: zod_1.z.any().nullable().optional(),
    })),
    usage: exports.UsageSchema.optional(),
    // HALO extensions
    halo_metadata: zod_1.z
        .object({
        chunks_count: zod_1.z.number().optional(),
        latency_ms: zod_1.z.number().optional(),
    })
        .optional(),
});
/**
 * Final aggregate chunk schema
 */
exports.FinalChunkSchema = exports.SSEChunkSchema.extend({
    choices: zod_1.z.array(zod_1.z.object({
        index: zod_1.z.number(),
        delta: zod_1.z.object({
            content: zod_1.z.string(),
        }),
        finish_reason: zod_1.z.enum(["stop", "length", "tool_calls", "content_filter"]).nullable(),
    })),
});
//# sourceMappingURL=chatCompletionTypes.js.map