"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getEnvVar = void 0;
const dotenv = __importStar(require("dotenv"));
const exceptions_1 = require("./exceptions");
/**
 * Initialize environment variables from .env file
 * This should be called at application startup
 */
dotenv.config();
/**
 * Retrieves and validates environment variables
 *
 * @param key - Name of the environment variable to retrieve
 * @param defaultValue - Optional default value if variable is not set
 * @returns The value of the environment variable or default
 * @throws {APIException} If the environment variable is not set and no default provided
 *
 * Usage:
 * ```typescript
 * const apiKey = getEnvVar('AZURE_OPENAI_API_KEY');
 * const endpoint = getEnvVar('AZURE_OPENAI_ENDPOINT');
 * const optional = getEnvVar('OPTIONAL_VAR', 'default');
 * ```
 *
 * Required Environment Variables:
 * - AZURE_OPENAI_API_KEY: API key for Azure OpenAI service
 * - AZURE_OPENAI_ENDPOINT: Endpoint URL for Azure OpenAI service
 */
const getEnvVar = (key, defaultValue) => {
    const value = process.env[key];
    console.log(`Loading ENV Variable ${key}`);
    if (!value) {
        if (defaultValue !== undefined) {
            return defaultValue;
        }
        throw new exceptions_1.APIException(`The ENV Variable named ${key} is not set. Please adjust the Azure Function ENV settings.`, 400, "ENV_VARIABLE_MISSING");
    }
    return value;
};
exports.getEnvVar = getEnvVar;
//# sourceMappingURL=config.js.map