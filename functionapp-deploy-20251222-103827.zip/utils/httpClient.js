"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.axiosInstance = void 0;
exports.createHttpClient = createHttpClient;
const axios_1 = __importDefault(require("axios"));
const https_1 = require("https");
/**
 * HTTP Client with Connection Keep-Alive
 *
 * Singleton axios instance with connection pooling for better performance
 * in Azure Functions environment
 */
// Singleton agent for connection reuse
const httpsAgent = new https_1.Agent({
    keepAlive: true,
    keepAliveMsecs: 30000, // 30 seconds
    maxSockets: 50,
    maxFreeSockets: 10,
    timeout: 120000, // 2 minutes
});
/**
 * Shared axios instance with keep-alive enabled
 */
exports.axiosInstance = axios_1.default.create({
    httpsAgent,
    timeout: 120000, // 2 minutes
    headers: {
        "User-Agent": "HALO-Layer/1.0",
    },
});
/**
 * Create a new axios instance with custom configuration
 */
function createHttpClient(config) {
    const agent = config?.keepAlive !== false
        ? new https_1.Agent({
            keepAlive: true,
            keepAliveMsecs: 30000,
            maxSockets: 50,
            maxFreeSockets: 10,
            timeout: config?.timeout || 120000,
        })
        : undefined;
    return axios_1.default.create({
        httpsAgent: agent,
        timeout: config?.timeout || 120000,
        headers: {
            "User-Agent": "HALO-Layer/1.0",
        },
    });
}
//# sourceMappingURL=httpClient.js.map