"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getHttpResponseInitJson = exports.createJsonResponseContent = exports.addCorsHeaders = void 0;
const readVersionFile_1 = require("./readVersionFile");
const corsHeaders = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
};
const addCorsHeaders = (headers = {}) => ({
    ...headers,
    ...corsHeaders,
});
exports.addCorsHeaders = addCorsHeaders;
/**
 * Creates a standardized success HTTP response.
 *
 * This function builds a response object containing the API version,
 * the time elapsed since the start of processing, and the results from
 * the Azure OpenAI API call.
 *
 * @param startTime - The timestamp (in milliseconds) when processing started.
 * @param response - The successful response data from the Azure OpenAI API.
 * @param errorResponse - The error data if the API call failed.
 * @param payload - The payload sent to the Azure OpenAI API.
 * @param headers - The headers returned or used in the API call.
 * @param parameters - The parameters used in the API call.
 * @returns An object conforming to SuccessResponse.
 */
const createJsonResponseContent = (startTime, response, errorResponse, payload, headers, parameters) => {
    const timeElapsed = Date.now() - startTime;
    // Create a copy of parameters without pre_prompts
    const filteredParameters = { ...parameters };
    delete filteredParameters.pre_prompts;
    return {
        status: 200,
        body: {
            version: readVersionFile_1.VERSION,
            time: timeElapsed,
            response: response ?? errorResponse,
            payload: payload,
            headers: headers,
            parameters: filteredParameters,
        },
        headers: (0, exports.addCorsHeaders)({ "Content-Type": "application/json" }),
    };
};
exports.createJsonResponseContent = createJsonResponseContent;
const getHttpResponseInitJson = (statusCode, body) => {
    return {
        status: statusCode,
        body: JSON.stringify(body, null, 2),
        headers: (0, exports.addCorsHeaders)({ "Content-Type": "application/json" }),
    };
};
exports.getHttpResponseInitJson = getHttpResponseInitJson;
//# sourceMappingURL=httpJsonResponse.js.map