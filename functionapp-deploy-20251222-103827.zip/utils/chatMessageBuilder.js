"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildChatMessages = void 0;
const estimateTokens = (text) => Math.ceil(text.length / 4);
const sortHistory = (history) => {
    return [...history].sort((a, b) => {
        if (a.created_at && b.created_at) {
            return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
        }
        return 0;
    });
};
const applyHistoryStrategy = (history, strategy, historyWindow, maxHistoryTokens) => {
    if (history.length === 0)
        return [];
    const sorted = sortHistory(history);
    if (strategy === "all") {
        return sorted;
    }
    if (strategy === "token_budget") {
        if (!maxHistoryTokens)
            return sorted;
        let total = 0;
        const selected = [];
        for (const message of [...sorted].reverse()) {
            const messageTokens = estimateTokens(message.content);
            if (total + messageTokens > maxHistoryTokens)
                break;
            total += messageTokens;
            selected.push(message);
        }
        return selected.reverse();
    }
    // Default strategy: last_n
    if (historyWindow <= 0)
        return [];
    return sorted.slice(-historyWindow);
};
const buildChatMessages = (params) => {
    const messages = [];
    const systemPrompts = params.system_prompt
        ? Array.isArray(params.system_prompt)
            ? params.system_prompt
            : [params.system_prompt]
        : [];
    for (const prompt of systemPrompts) {
        messages.push({ role: "system", content: prompt });
    }
    if (Array.isArray(params.pre_prompts)) {
        for (const prePrompt of params.pre_prompts) {
            messages.push({
                role: prePrompt.role ?? "system",
                content: prePrompt.text,
            });
        }
    }
    const historyStrategy = params.history_strategy ?? "last_n";
    const historyWindow = params.history_window ?? 3;
    const history = applyHistoryStrategy(params.history ?? [], historyStrategy, historyWindow, params.max_history_tokens);
    messages.push(...history);
    const prompts = Array.isArray(params.prompt) ? params.prompt : [params.prompt];
    for (const prompt of prompts) {
        messages.push({ role: "user", content: prompt });
    }
    return messages;
};
exports.buildChatMessages = buildChatMessages;
//# sourceMappingURL=chatMessageBuilder.js.map