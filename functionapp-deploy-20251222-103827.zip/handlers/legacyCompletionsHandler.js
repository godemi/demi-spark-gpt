"use strict";
//# sourceMappingURL=legacyCompletionsHandler.js.map