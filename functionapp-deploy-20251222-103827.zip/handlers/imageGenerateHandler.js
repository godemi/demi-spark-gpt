"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.imageGenerateHandler = void 0;
const uuid_1 = require("uuid");
const openai_1 = __importDefault(require("openai"));
const providers_1 = require("../config/providers");
const exceptions_1 = require("../utils/exceptions");
const httpJsonResponse_1 = require("../utils/httpJsonResponse");
const outputProcessor_1 = require("../attachments/outputProcessor");
const logger_1 = require("../observability/logger");
const telemetry_1 = require("../observability/telemetry");
/**
 * Handles POST /v1/images/generations requests
 *
 * Image generation endpoint (DALL-E, etc.)
 */
const imageGenerateHandler = async (request, context) => {
    // Handle CORS preflight
    if (request.method === "OPTIONS") {
        return {
            status: 204,
            headers: (0, httpJsonResponse_1.addCorsHeaders)(),
        };
    }
    const startTime = Date.now();
    const requestId = (0, uuid_1.v4)();
    try {
        // Parse request body
        const body = await request.text();
        if (!body) {
            throw new exceptions_1.APIException("Request body is empty. Please provide a valid JSON body.", 400, "EMPTY_REQUEST_BODY", undefined, requestId);
        }
        let requestJson;
        try {
            requestJson = JSON.parse(body);
        }
        catch (parseError) {
            throw new exceptions_1.APIException("Invalid JSON received.", 400, "INVALID_JSON", undefined, requestId);
        }
        // Validate required fields
        if (!requestJson.prompt) {
            throw new exceptions_1.APIException("Missing required field: prompt", 400, "MISSING_FIELD", undefined, requestId);
        }
        const provider = requestJson.provider || "openai";
        const model = requestJson.model || "dall-e-3";
        const prompt = requestJson.prompt;
        const n = requestJson.n || 1;
        const size = requestJson.size || "1024x1024";
        const quality = requestJson.quality || "standard";
        const response_format = requestJson.response_format || "url";
        // Build provider config (pass model name for model-specific endpoint lookup)
        const providerConfig = (0, providers_1.buildProviderConfig)(provider, undefined, undefined, undefined, model);
        // Log request
        (0, logger_1.logRequest)(context, {
            requestId,
            model,
            provider,
            messageCount: 0,
            stream: false,
        });
        // Generate image
        let response;
        if (provider === "openai") {
            const openai = new openai_1.default({
                apiKey: providerConfig.apiKey,
                organization: providerConfig.organization,
            });
            response = await openai.images.generate({
                model: model,
                prompt,
                n,
                size: size,
                quality: quality,
                response_format: response_format,
            });
        }
        else {
            throw new exceptions_1.APIException(`Image generation not yet supported for provider: ${provider}`, 400, "UNSUPPORTED_PROVIDER", undefined, requestId);
        }
        const latencyMs = Date.now() - startTime;
        // Process attachments
        const attachments = (0, outputProcessor_1.processImageGenerationResponse)(response);
        // Build response
        const haloResponse = {
            request_id: requestId,
            provider,
            model,
            created: response.created,
            attachments,
            latency_ms: latencyMs,
        };
        // Track telemetry
        telemetry_1.telemetry.trackRequest({
            requestId,
            model,
            provider,
            latencyMs,
            promptTokens: 0, // Image generation doesn't use tokens
            completionTokens: 0,
            streaming: false,
            attachmentCount: attachments.length,
            success: true,
            context,
        });
        (0, logger_1.logResponse)(context, {
            requestId,
            success: true,
            latencyMs,
        });
        return {
            status: 200,
            body: JSON.stringify(haloResponse, null, 2),
            headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
        };
    }
    catch (error) {
        const latencyMs = Date.now() - startTime;
        if (error instanceof exceptions_1.APIException) {
            (0, logger_1.logError)(context, error, requestId);
            telemetry_1.telemetry.trackRequest({
                requestId,
                model: "unknown",
                provider: "unknown",
                latencyMs,
                promptTokens: 0,
                completionTokens: 0,
                streaming: false,
                attachmentCount: 0,
                success: false,
                errorCode: error.errorCode,
                context,
            });
            return {
                status: error.statusCode,
                body: JSON.stringify(error.toResponse(), null, 2),
                headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
            };
        }
        // Unexpected error
        const apiError = new exceptions_1.APIException("Internal Server Error", 500, `An unexpected error occurred: ${error instanceof Error ? error.message : String(error)}`, undefined, requestId);
        (0, logger_1.logError)(context, apiError, requestId, { originalError: String(error) });
        telemetry_1.telemetry.trackError(apiError, requestId, context);
        return {
            status: 500,
            body: JSON.stringify(apiError.toResponse(), null, 2),
            headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
        };
    }
};
exports.imageGenerateHandler = imageGenerateHandler;
//# sourceMappingURL=imageGenerateHandler.js.map