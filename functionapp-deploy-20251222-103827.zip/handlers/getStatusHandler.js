"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getStatusHandler = getStatusHandler;
const axios_1 = __importDefault(require("axios"));
const axios_retry_1 = __importDefault(require("axios-retry"));
const exceptions_1 = require("../utils/exceptions");
const httpJsonResponse_1 = require("../utils/httpJsonResponse");
const readVersionFile_1 = require("../utils/readVersionFile");
/**
 * Handles Axios errors and converts them to standardized APIException format
 * @param error - The Axios error to handle
 * @throws APIException with appropriate status code and message
 */
const handleAxiosError = (error) => {
    if (error.code === "ECONNABORTED") {
        throw new exceptions_1.APIException("Connection timeout", 504, "The request timed out while trying to connect to the OpenAI API");
    }
    if (error.code === "ECONNREFUSED") {
        throw new exceptions_1.APIException("Connection refused", 503, "Could not establish connection to the OpenAI API");
    }
    if (!error.response) {
        throw new exceptions_1.APIException("Network error", 503, `Network error occurred: ${error.message}`);
    }
    throw new exceptions_1.APIException("OpenAI API error", error.response?.status || 503, `Service error: ${error.message}`);
};
/**
 * Creates a standardized HTTP response
 * @param status - HTTP status code
 * @param body - Response body object
 * @param errorCode - Optional error code for error responses
 * @returns Formatted HTTP response
 */
const createResponse = (status, body, errorCode) => ({
    status,
    body: JSON.stringify(body, null, 2),
    headers: (0, httpJsonResponse_1.addCorsHeaders)({
        "Content-Type": "application/json",
        ...(errorCode && { "X-Error-Code": errorCode }),
    }),
});
/**
 * Handles GET /status requests to check API and Azure OpenAI availability
 * @param request - The HTTP request object
 * @param context - Azure Functions invocation context
 * @returns HTTP response with status information
 *
 * Status checks performed:
 * 1. Validates Azure OpenAI endpoint URL
 * 2. Attempts connection with retry mechanism
 * 3. Verifies authentication and authorization
 * 4. Returns detailed status information
 */
async function getStatusHandler(request, context) {
    try {
        // Check if any model-specific configurations exist
        const modelConfigs = [];
        for (const [key] of Object.entries(process.env)) {
            if (key.startsWith("AZURE_OPENAI_ENDPOINT_") && !key.includes("_API_KEY_") && !key.includes("_API_VERSION_") && !key.includes("_AUTH_TYPE_")) {
                const modelName = key.replace("AZURE_OPENAI_ENDPOINT_", "").toLowerCase().replace(/_/g, "-");
                modelConfigs.push(modelName);
            }
        }
        if (modelConfigs.length === 0) {
            throw new exceptions_1.APIException("No model configurations found", 500, "Please configure at least one model using AZURE_OPENAI_ENDPOINT_<MODEL> and AZURE_OPENAI_API_KEY_<MODEL> environment variables.");
        }
        // Use the first configured model for status check
        const firstModel = modelConfigs[0];
        const modelEnvKey = firstModel.toUpperCase().replace(/[^A-Z0-9]/g, "_");
        const openAIUrl = process.env[`AZURE_OPENAI_ENDPOINT_${modelEnvKey}`];
        const apiKey = process.env[`AZURE_OPENAI_API_KEY_${modelEnvKey}`];
        if (!openAIUrl || !apiKey) {
            throw new exceptions_1.APIException(`Incomplete configuration for model: ${firstModel}`, 500, `Please set both AZURE_OPENAI_ENDPOINT_${modelEnvKey} and AZURE_OPENAI_API_KEY_${modelEnvKey} environment variables.`);
        }
        // Validate URL format
        try {
            new URL(openAIUrl);
        }
        catch {
            throw new exceptions_1.APIException("Invalid Azure OpenAI endpoint URL", 400, "The AZURE_OPENAI_ENDPOINT environment variable contains an invalid URL");
        }
        // Configure axios with retry mechanism
        const client = axios_1.default.create({
            timeout: 5000, // 5 second timeout
            validateStatus: status => status < 500, // Don't reject on non-500 errors
        });
        // Setup retry configuration
        (0, axios_retry_1.default)(client, {
            retries: 3,
            retryDelay: axios_retry_1.default.exponentialDelay,
            retryCondition: error => axios_retry_1.default.isNetworkOrIdempotentRequestError(error) ||
                error.code === "ECONNABORTED" ||
                (error.response?.status ?? 0) >= 500,
        });
        let openaiStatus = "unreachable";
        let statusDetails = "";
        try {
            // Test Azure OpenAI connection with minimal request
            const response = await client.post(openAIUrl, {
                messages: [{ role: "user", content: "Hello" }],
                max_tokens: 1,
            }, {
                headers: {
                    "Content-Type": "application/json",
                    "api-key": apiKey,
                },
            });
            // Handle different response status codes
            switch (response.status) {
                case 200:
                    openaiStatus = "reachable";
                    break;
                case 401:
                    throw new exceptions_1.APIException("Authentication failed", 401, "Invalid API key or authentication token");
                case 403:
                    throw new exceptions_1.APIException("Access forbidden", 403, "The API key doesn't have permission to access this endpoint");
                case 404:
                    throw new exceptions_1.APIException("Endpoint not found", 404, "The specified Azure OpenAI endpoint URL is incorrect");
                case 429:
                    throw new exceptions_1.APIException("Rate limit exceeded", 429, "Too many requests. Please try again later");
                default:
                    openaiStatus = `error (${response.status})`;
                    statusDetails = response.data?.error?.message || "Unknown error";
                    break;
            }
        }
        catch (error) {
            // Handle different types of errors
            if (error instanceof exceptions_1.APIException) {
                throw error;
            }
            if (axios_1.default.isAxiosError(error)) {
                handleAxiosError(error);
            }
            throw new exceptions_1.APIException("Unexpected error", 500, `An unexpected error occurred: ${error}`);
        }
        // Return success response
        return createResponse(200, {
            status: "ok",
            spark_gpt_status: "reachable",
            spark_azure_openai_status: openaiStatus,
            details: statusDetails || undefined,
            timestamp: new Date().toISOString(),
            version: readVersionFile_1.VERSION,
        });
    }
    catch (error) {
        // Handle and format all errors
        if (error instanceof exceptions_1.APIException) {
            return createResponse(error.statusCode, { ...error.toResponse(), version: readVersionFile_1.VERSION }, error.statusCode.toString());
        }
        const apiError = new exceptions_1.APIException("Internal Server Error", 500, `Unexpected error occurred: ${error instanceof Error ? error.message : String(error)}`);
        return createResponse(500, { ...apiError.toResponse(), version: readVersionFile_1.VERSION }, "500");
    }
}
//# sourceMappingURL=getStatusHandler.js.map