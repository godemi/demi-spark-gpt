"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getInfoHandler = void 0;
const zod_1 = require("zod");
const parameterConstraints_1 = require("../models/parameterConstraints");
const parameterMetadata_1 = require("../models/parameterMetadata");
const types_1 = require("../models/types");
const httpJsonResponse_1 = require("../utils/httpJsonResponse");
/**
 * Formats and extracts type information from a Zod schema
 * @param paramName - Name of the parameter being processed
 * @param paramSchema - Zod schema of the parameter
 * @returns Formatted parameter metadata
 */
function formatType(paramName, paramSchema) {
    // Initialize metadata with default values
    const metadata = {
        optional: false,
        type: "unknown",
        allowed_values: null,
        description: parameterMetadata_1.PARAMETER_METADATA[paramName]?.description ?? "",
        usage: parameterMetadata_1.PARAMETER_METADATA[paramName]?.usage ?? "",
    };
    // Unwrap effects (e.g., coerced numbers)
    if (paramSchema instanceof zod_1.z.ZodEffects) {
        paramSchema = paramSchema._def.schema;
    }
    // Handle optional parameters
    if (paramSchema instanceof zod_1.z.ZodOptional) {
        metadata.optional = true;
        paramSchema = paramSchema.unwrap();
    }
    // Handle different parameter types
    if (paramSchema instanceof zod_1.z.ZodObject) {
        // Process object type parameters
        metadata.type = "object";
        metadata.properties = {};
        for (const [key, schema] of Object.entries(paramSchema.shape)) {
            metadata.properties[key] = formatType(key, schema);
        }
    }
    else if (paramSchema instanceof zod_1.z.ZodArray) {
        // Process array type parameters
        const elementMetadata = formatType("", paramSchema.element);
        if (elementMetadata.type === "object" && elementMetadata.properties) {
            metadata.type = "array";
            metadata.properties = elementMetadata.properties;
        }
        else {
            metadata.type = `${elementMetadata.type}[]`;
        }
    }
    else if (paramSchema instanceof zod_1.z.ZodString) {
        metadata.type = "string";
    }
    else if (paramSchema instanceof zod_1.z.ZodNumber) {
        metadata.type = "number";
    }
    else if (paramSchema instanceof zod_1.z.ZodBoolean) {
        metadata.type = "boolean";
        metadata.allowed_values = "true | false";
    }
    else if (paramSchema instanceof zod_1.z.ZodEnum) {
        metadata.type = "enum";
        metadata.allowed_values = paramSchema.options.map(String).join(" | ");
    }
    else if (paramSchema instanceof zod_1.z.ZodUnion) {
        metadata.type = paramSchema._def.options
            .map((option) => formatType("", option).type)
            .join(" | ");
    }
    else if (paramSchema instanceof zod_1.z.ZodRecord) {
        metadata.type = "record";
        const valueType = formatType("", paramSchema._def.valueType).type;
        metadata.type = `Record<string, ${valueType}>`;
    }
    // Add constraint information if available
    if (paramName in parameterConstraints_1.PARAMETER_CONSTRAINTS) {
        const constraint = parameterConstraints_1.PARAMETER_CONSTRAINTS[paramName];
        const { min: minVal, max: maxVal } = constraint;
        if (minVal !== undefined && maxVal !== undefined) {
            metadata.allowed_values = `range(${minVal}, ${maxVal})`;
        }
        else if (minVal !== undefined) {
            metadata.allowed_values = `range(${minVal}, ∞)`;
        }
        else if (maxVal !== undefined) {
            metadata.allowed_values = `range(-∞, ${maxVal})`;
        }
    }
    return metadata;
}
/**
 * Handles GET /info requests
 * Returns API documentation including parameter descriptions and constraints
 * @param request - The HTTP request
 * @param context - The function invocation context
 * @returns HTTP response with API documentation
 */
const getInfoHandler = async (request, context) => {
    try {
        // Get all parameters from the Zod schema
        const shape = types_1.SparkGPTInputParametersSchema.shape;
        // Convert schema definitions into detailed metadata
        const parametersInfo = {};
        for (const [param, paramSchema] of Object.entries(shape)) {
            parametersInfo[param] = formatType(param, paramSchema);
        }
        // Construct API documentation
        const apiInfo = {
            description: "This API provides a ChatGPT-powered chat and completions functionality.",
            endpoints: {
                "POST /completions": "Send a chat request with JSON body containing parameters.",
                "GET /status": "Check if the API and ChatGPT are reachable.",
                "GET /info": "Retrieve API documentation.",
            },
            parameters: parametersInfo,
        };
        return {
            status: 200,
            body: JSON.stringify(apiInfo, null, 2),
            headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
        };
    }
    catch (e) {
        return {
            status: 500,
            body: JSON.stringify({
                error: `Internal Server Error (${e.constructor.name}): ${e.message}`,
            }),
            headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
        };
    }
};
exports.getInfoHandler = getInfoHandler;
//# sourceMappingURL=getInfoHandler.js.map