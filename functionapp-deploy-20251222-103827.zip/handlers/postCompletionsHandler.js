"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postCompletionsHandler = void 0;
const azureChatGPTRequest_1 = require("../utils/azureChatGPTRequest");
const exceptions_1 = require("../utils/exceptions");
const httpJsonResponse_1 = require("../utils/httpJsonResponse");
const chatMessageBuilder_1 = require("../utils/chatMessageBuilder");
const processPrePrompts_1 = require("../utils/processPrePrompts");
const validation_1 = require("../utils/validation");
/**
 * Handles POST /completions requests to process chat completion requests
 * @param request - The HTTP request object containing completion parameters
 * @param context - Azure Functions invocation context
 * @returns HTTP response with completion results or error details
 *
 * Processing steps:
 * 1. Validates JSON request body
 * 2. Converts and validates input parameters
 * 3. Processes pre-prompts and variables
 * 4. Makes Azure OpenAI API request
 * 5. Returns formatted response with timing information
 *
 * Error handling:
 * - Returns 400 for invalid requests
 * - Returns 500 for unexpected errors
 * - Includes detailed error information in response
 */
const postCompletionsHandler = async (request, context) => {
    // Handle CORS preflight requests
    if (request.method === "OPTIONS") {
        return {
            status: 204,
            headers: (0, httpJsonResponse_1.addCorsHeaders)(),
        };
    }
    const startTime = Date.now();
    let requestJson;
    try {
        // Check if request body is empty
        const body = await request.text();
        if (!body) {
            throw new exceptions_1.APIException("Request body is empty. Please provide a valid JSON body.", 400, "EMPTY_REQUEST_BODY");
        }
        // Parse and validate request JSON
        try {
            requestJson = JSON.parse(body);
        }
        catch (parseError) {
            throw new exceptions_1.APIException("Invalid JSON received. Ensure the request has a valid JSON body with Content-Type: application/json.", 400, parseError instanceof Error ? parseError.message : "Invalid JSON format");
        }
        if (!requestJson || typeof requestJson !== "object" || Array.isArray(requestJson)) {
            throw new exceptions_1.APIException("Invalid request body. The request must contain a valid JSON object.", 400, "Request body must be a non-null JSON object.");
        }
        // Validate and process parameters.
        const inputParams = (0, validation_1.validateAndConvertParams)(requestJson);
        const processedParams = (0, processPrePrompts_1.generatePrePrompts)(inputParams);
        const chatMessages = (0, chatMessageBuilder_1.buildChatMessages)(processedParams);
        // Check streaming support.
        if (processedParams.stream === true) {
            return (0, azureChatGPTRequest_1.returnAzureChatGPTRequestStream)(context, processedParams, startTime, chatMessages);
        }
        // Make Azure OpenAI API request
        const { response, payload, headers, errorResponse } = await (0, azureChatGPTRequest_1.getAzureChatGPTRequestJson)(processedParams, chatMessages);
        // Return success response
        return (0, httpJsonResponse_1.getHttpResponseInitJson)(200, (0, httpJsonResponse_1.createJsonResponseContent)(startTime, response, errorResponse, payload, headers, processedParams));
    }
    catch (error) {
        // Handle known API exceptions
        console.log("Caught error type:", error?.constructor?.name);
        console.log("Error details:", error);
        if (error instanceof exceptions_1.APIException) {
            console.log("Handling APIException with status:", error.statusCode);
            return {
                status: error.statusCode,
                body: JSON.stringify(error.toResponse(), null, 2),
                headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
            };
        }
        // Handle unexpected errors
        console.log("Handling unexpected error");
        const apiError = new exceptions_1.APIException("Internal Server Error", 500, `An unexpected error occurred: ${error instanceof Error ? error.message : String(error)}`);
        return {
            status: 500,
            body: JSON.stringify(apiError.toResponse(), null, 2),
            headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
        };
    }
};
exports.postCompletionsHandler = postCompletionsHandler;
//# sourceMappingURL=postCompletionsHandler.js.map