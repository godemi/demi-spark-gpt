"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.chatCompletionsHandler = void 0;
const uuid_1 = require("uuid");
const inputProcessor_1 = require("../attachments/inputProcessor");
const providers_1 = require("../config/providers");
const profiles_1 = require("../guardrails/profiles");
const chatCompletionTypes_1 = require("../models/chatCompletionTypes");
const logger_1 = require("../observability/logger");
const telemetry_1 = require("../observability/telemetry");
const providers_2 = require("../providers");
const sseWriter_1 = require("../streaming/sseWriter");
const exceptions_1 = require("../utils/exceptions");
const httpJsonResponse_1 = require("../utils/httpJsonResponse");
/**
 * Handles POST /v1/chat/completions requests
 *
 * Main HALO layer endpoint for chat completions with:
 * - Multi-provider routing
 * - Streaming and non-streaming support
 * - Attachments support
 * - Tool calling
 * - Observability
 */
const chatCompletionsHandler = async (request, context) => {
    // Handle CORS preflight
    if (request.method === "OPTIONS") {
        return {
            status: 204,
            headers: (0, httpJsonResponse_1.addCorsHeaders)(),
        };
    }
    const startTime = Date.now();
    const requestId = (0, uuid_1.v4)();
    let chatRequest;
    try {
        // Parse request body
        const body = await request.text();
        if (!body) {
            throw new exceptions_1.APIException("Request body is empty. Please provide a valid JSON body.", 400, "EMPTY_REQUEST_BODY", undefined, requestId);
        }
        let requestJson;
        try {
            requestJson = JSON.parse(body);
        }
        catch (parseError) {
            throw new exceptions_1.APIException("Invalid JSON received. Ensure the request has a valid JSON body with Content-Type: application/json.", 400, parseError instanceof Error ? parseError.message : "Invalid JSON format", undefined, requestId);
        }
        // Validate request schema
        const validationResult = chatCompletionTypes_1.ChatCompletionRequestSchema.safeParse(requestJson);
        if (!validationResult.success) {
            const errors = validationResult.error.issues
                .map(issue => `${issue.path.join(".")}: ${issue.message}`)
                .join("; ");
            throw new exceptions_1.APIException(`Invalid request parameters: ${errors}`, 400, "INVALID_PARAMETERS", undefined, requestId);
        }
        chatRequest = validationResult.data;
        // Determine provider (default to azure-openai if not specified)
        const provider = chatRequest.provider || "azure-openai";
        // Get provider adapter
        const adapter = (0, providers_2.getProviderAdapter)(provider);
        if (!adapter) {
            throw new exceptions_1.APIException(`Unknown provider: ${provider}`, 400, "UNKNOWN_PROVIDER", undefined, requestId);
        }
        // Load environment config for defaults
        const envConfig = (0, providers_1.loadProviderConfig)();
        // Resolve model from direct model, task_profile, or default
        let resolvedModel;
        try {
            resolvedModel = (0, providers_2.resolveModel)({
                requestModel: chatRequest.model,
                taskProfile: chatRequest.task_profile,
                defaultModel: envConfig.azure_openai.deployment,
                defaultDeployment: envConfig.azure_openai.deployment,
            });
        }
        catch (resolveError) {
            throw new exceptions_1.APIException(resolveError instanceof Error ? resolveError.message : String(resolveError), 400, "INVALID_TASK_PROFILE", undefined, requestId);
        }
        // Apply resolved model settings to the request
        const resolvedRequest = (0, providers_2.applyResolvedModelSettings)(resolvedModel, chatRequest);
        const effectiveModel = resolvedModel.model;
        // Validate model capabilities
        const capabilities = adapter.getCapabilities(effectiveModel);
        if (!capabilities) {
            throw new exceptions_1.APIException(`Unknown model: ${effectiveModel}`, 400, "UNKNOWN_MODEL", undefined, requestId);
        }
        // Check if model supports requested features
        if (resolvedRequest.messages.some(m => m.attachments?.length)) {
            if (!capabilities.vision) {
                throw new exceptions_1.APIException(`Model ${effectiveModel} does not support vision/attachments`, 400, "CAPABILITY_NOT_SUPPORTED", undefined, requestId);
            }
        }
        if (resolvedRequest.tools && resolvedRequest.tools.length > 0) {
            if (!capabilities.tool_calls) {
                throw new exceptions_1.APIException(`Model ${effectiveModel} does not support tool calling`, 400, "CAPABILITY_NOT_SUPPORTED", undefined, requestId);
            }
        }
        // Build provider config with resolved deployment
        let providerConfig;
        try {
            providerConfig = (0, providers_1.buildProviderConfig)(provider, resolvedRequest.azure_endpoint, resolvedModel.deployment || resolvedRequest.azure_deployment, resolvedRequest.api_version, effectiveModel);
        }
        catch (configError) {
            const errorMessage = configError instanceof Error ? configError.message : String(configError);
            // Provide helpful message for missing environment variables
            if (errorMessage.includes("ENV Variable") || errorMessage.includes("not set")) {
                throw new exceptions_1.APIException(`Missing required environment variable: ${errorMessage}\n\n` +
                    `Please set the required environment variables:\n` +
                    `- AZURE_OPENAI_ENDPOINT: Your Azure OpenAI endpoint URL\n` +
                    `- AZURE_OPENAI_API_KEY: Your Azure OpenAI API key\n\n` +
                    `For local development, set these in local.settings.json or .env file.\n` +
                    `For production, set them in Azure Portal > Function App > Configuration.`, 500, "MISSING_ENV_VARIABLE", undefined, requestId);
            }
            throw new exceptions_1.APIException(`Failed to build provider configuration: ${errorMessage}`, 500, "PROVIDER_CONFIG_ERROR", undefined, requestId);
        }
        // Process attachments
        let processedMessages = resolvedRequest.messages;
        if (resolvedRequest.messages.some(m => m.attachments?.length)) {
            processedMessages = await (0, inputProcessor_1.processInputAttachments)(resolvedRequest.messages, capabilities);
        }
        // Apply guardrails if enabled
        if (resolvedRequest.system_guardrails_enabled && resolvedRequest.guardrail_profile) {
            processedMessages = (0, profiles_1.applyGuardrails)(processedMessages, resolvedRequest.guardrail_profile);
        }
        // Log request (include task_profile info if used)
        (0, logger_1.logRequest)(context, {
            requestId,
            model: effectiveModel,
            provider,
            messageCount: processedMessages.length,
            stream: resolvedRequest.stream || false,
            hasAttachments: resolvedRequest.messages.some(m => m.attachments?.length),
            taskProfile: resolvedModel.task_profile,
            modelSource: resolvedModel.source,
        });
        // Build provider request with resolved settings
        let providerRequest;
        try {
            providerRequest = await adapter.buildRequest(resolvedRequest, providerConfig);
        }
        catch (buildError) {
            const errorMessage = buildError instanceof Error ? buildError.message : String(buildError);
            // Check if it's a parameter validation error
            if (errorMessage.includes("does not support")) {
                throw new exceptions_1.APIException(errorMessage, 400, "UNSUPPORTED_PARAMETER", undefined, requestId);
            }
            // Re-throw other errors
            throw new exceptions_1.APIException(`Failed to build provider request: ${errorMessage}`, 500, "PROVIDER_REQUEST_BUILD_ERROR", undefined, requestId);
        }
        // Execute request
        if (resolvedRequest.stream) {
            return await handleStreaming(adapter, providerRequest, providerConfig, requestId, startTime, context, effectiveModel, provider);
        }
        else {
            return await handleNonStreaming(adapter, providerRequest, providerConfig, requestId, startTime, context, effectiveModel, provider);
        }
    }
    catch (error) {
        const latencyMs = Date.now() - startTime;
        if (error instanceof exceptions_1.APIException) {
            (0, logger_1.logError)(context, error, requestId);
            telemetry_1.telemetry.trackRequest({
                requestId,
                model: chatRequest?.model || "unknown",
                provider: chatRequest?.provider || "unknown",
                latencyMs,
                promptTokens: 0,
                completionTokens: 0,
                streaming: false,
                attachmentCount: 0,
                success: false,
                errorCode: error.errorCode,
                context,
            });
            return {
                status: error.statusCode,
                body: JSON.stringify(error.toResponse(), null, 2),
                headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
            };
        }
        // Unexpected error
        const apiError = new exceptions_1.APIException("Internal Server Error", 500, `An unexpected error occurred: ${error instanceof Error ? error.message : String(error)}`, undefined, requestId);
        (0, logger_1.logError)(context, apiError, requestId, { originalError: String(error) });
        telemetry_1.telemetry.trackError(apiError, requestId, context);
        return {
            status: 500,
            body: JSON.stringify(apiError.toResponse(), null, 2),
            headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
        };
    }
};
exports.chatCompletionsHandler = chatCompletionsHandler;
/**
 * Handle streaming response
 */
async function handleStreaming(adapter, providerRequest, providerConfig, requestId, startTime, context, model, provider) {
    const sseWriter = new sseWriter_1.SSEWriter();
    const stream = adapter.executeStream(providerRequest, providerConfig);
    return {
        status: 200,
        headers: (0, httpJsonResponse_1.addCorsHeaders)({
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
            Connection: "keep-alive",
        }),
        body: new ReadableStream({
            async start(controller) {
                try {
                    for await (const chunk of sseWriter.stream(stream, requestId)) {
                        controller.enqueue(new TextEncoder().encode(chunk));
                    }
                    controller.close();
                }
                catch (error) {
                    context.error("Streaming error:", error);
                    controller.error(error);
                }
            },
        }),
    };
}
/**
 * Handle non-streaming response
 */
async function handleNonStreaming(adapter, providerRequest, providerConfig, requestId, startTime, context, model, provider) {
    const response = await adapter.executeJson(providerRequest, providerConfig);
    const latencyMs = Date.now() - startTime;
    // Add HALO extensions
    const haloResponse = {
        ...response,
        request_id: requestId,
        provider,
        latency_ms: latencyMs,
    };
    // Track telemetry
    telemetry_1.telemetry.trackRequest({
        requestId,
        model,
        provider,
        latencyMs,
        promptTokens: response.usage?.prompt_tokens || 0,
        completionTokens: response.usage?.completion_tokens || 0,
        reasoningTokens: response.usage?.reasoning_tokens,
        streaming: false,
        attachmentCount: 0,
        success: true,
        context,
    });
    (0, logger_1.logResponse)(context, {
        requestId,
        success: true,
        latencyMs,
        promptTokens: response.usage?.prompt_tokens,
        completionTokens: response.usage?.completion_tokens,
    });
    return {
        status: 200,
        body: JSON.stringify(haloResponse, null, 2),
        headers: (0, httpJsonResponse_1.addCorsHeaders)({ "Content-Type": "application/json" }),
    };
}
//# sourceMappingURL=chatCompletionsHandler.js.map