"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AzureFoundryAdapter = void 0;
const openai_1 = __importDefault(require("openai"));
const identity_1 = require("@azure/identity");
const modelRegistry_1 = require("./modelRegistry");
/**
 * Azure AI Foundry Provider Adapter
 *
 * Handles requests to Azure AI Foundry for both Azure OpenAI deployments
 * and OSS "Models as a Service" (Llama, Mistral, Phi-3, etc.)
 *
 * Uses the same OpenAI-compatible API pattern as Azure OpenAI
 */
class AzureFoundryAdapter {
    name = "azure-ai-foundry";
    clients = new Map();
    /**
     * Get or create an Azure AI Foundry client for a configuration
     */
    getClient(config) {
        const key = `${config.endpoint}-${config.deployment || config.model}-${config.authType}`;
        if (this.clients.has(key)) {
            return this.clients.get(key);
        }
        let client;
        if (config.authType === "aad") {
            const credential = new identity_1.DefaultAzureCredential();
            client = new openai_1.default({
                baseURL: `${config.endpoint}/openai/deployments/${config.deployment || config.model}`,
                defaultQuery: { "api-version": config.apiVersion },
                defaultHeaders: {
                    "api-key": "", // Will be replaced by token
                },
            });
            // Set up token refresh
            const getToken = async () => {
                const token = await credential.getToken("https://cognitiveservices.azure.com/.default");
                return token.token;
            };
            client._getToken = getToken;
        }
        else {
            client = new openai_1.default({
                baseURL: `${config.endpoint}/openai/deployments/${config.deployment || config.model}`,
                defaultQuery: { "api-version": config.apiVersion },
                apiKey: config.apiKey,
            });
        }
        this.clients.set(key, client);
        return client;
    }
    async buildRequest(params, config) {
        // Azure AI Foundry uses the same request format as Azure OpenAI
        // Model is resolved from: config.deployment > config.model > params.model > default
        const model = config.deployment || config.model || params.model || "gpt-4o";
        const request = {
            model,
            messages: params.messages.map(this.normalizeMessage),
            stream: params.stream,
        };
        // Add optional parameters (OSS models may not support all)
        if (params.temperature !== undefined)
            request.temperature = params.temperature;
        if (params.top_p !== undefined)
            request.top_p = params.top_p;
        if (params.max_tokens !== undefined)
            request.max_tokens = params.max_tokens;
        if (params.max_completion_tokens !== undefined) {
            request.max_completion_tokens = params.max_completion_tokens;
        }
        if (params.response_format)
            request.response_format = params.response_format;
        if (params.tools)
            request.tools = params.tools;
        if (params.tool_choice)
            request.tool_choice = params.tool_choice;
        if (params.seed !== undefined)
            request.seed = params.seed;
        if (params.stop)
            request.stop = params.stop;
        if (params.presence_penalty !== undefined) {
            request.presence_penalty = params.presence_penalty;
        }
        if (params.frequency_penalty !== undefined) {
            request.frequency_penalty = params.frequency_penalty;
        }
        if (params.n !== undefined)
            request.n = params.n;
        if (params.user)
            request.user = params.user;
        // Note: OSS models typically don't support reasoning_mode, logprobs, etc.
        return request;
    }
    async *executeStream(request, config) {
        const client = this.getClient(config);
        try {
            const options = {
                ...request,
                stream: true,
            };
            if (config.authType === "aad" && client._getToken) {
                const token = await client._getToken();
                options.headers = {
                    Authorization: `Bearer ${token}`,
                };
            }
            const stream = (await client.chat.completions.create(options));
            for await (const chunk of stream) {
                yield this.mapChunk(chunk);
            }
        }
        catch (error) {
            throw this.mapError(error);
        }
    }
    async executeJson(request, config) {
        const client = this.getClient(config);
        try {
            const options = {
                ...request,
                stream: false,
            };
            if (config.authType === "aad" && client._getToken) {
                const token = await client._getToken();
                options.headers = {
                    Authorization: `Bearer ${token}`,
                };
            }
            const response = await client.chat.completions.create(options);
            return this.mapResponse(response);
        }
        catch (error) {
            throw this.mapError(error);
        }
    }
    getCapabilities(model) {
        return (0, modelRegistry_1.getModelCapabilities)(model);
    }
    validateRequest(request) {
        // Azure AI Foundry supports OpenAI-compatible API
        // Some OSS models may have limited capabilities
        return true;
    }
    /**
     * Normalize HALO message format to OpenAI format
     */
    normalizeMessage(msg) {
        // If message has attachments, convert to content array format
        if (msg.attachments && msg.attachments.length > 0) {
            const content = [];
            // Add text content if present
            if (typeof msg.content === "string" && msg.content.trim()) {
                content.push({ type: "text", text: msg.content });
            }
            else if (Array.isArray(msg.content)) {
                content.push(...msg.content);
            }
            // Add attachments as image_url (if model supports vision)
            for (const att of msg.attachments) {
                if (att.type === "image") {
                    const url = att.url || (att.data ? `data:${att.mime_type};base64,${att.data}` : undefined);
                    if (url) {
                        content.push({
                            type: "image_url",
                            image_url: {
                                url,
                                detail: "auto",
                            },
                        });
                    }
                }
            }
            return {
                role: msg.role,
                content,
                name: msg.name,
                tool_calls: msg.tool_calls,
                tool_call_id: msg.tool_call_id,
            };
        }
        // Otherwise, return as-is (already in OpenAI format)
        return {
            role: msg.role,
            content: msg.content,
            name: msg.name,
            tool_calls: msg.tool_calls,
            tool_call_id: msg.tool_call_id,
        };
    }
    /**
     * Map Azure AI Foundry chunk to HALO SSE chunk format
     */
    mapChunk(chunk) {
        return {
            id: chunk.id || "",
            object: "chat.completion.chunk",
            created: chunk.created || Math.floor(Date.now() / 1000),
            model: chunk.model || "",
            choices: (chunk.choices || []).map((choice) => ({
                index: choice.index || 0,
                delta: {
                    role: choice.delta?.role,
                    content: choice.delta?.content || null,
                    tool_calls: choice.delta?.tool_calls,
                },
                finish_reason: choice.finish_reason || null,
                logprobs: choice.logprobs || null,
            })),
            usage: chunk.usage
                ? {
                    prompt_tokens: chunk.usage.prompt_tokens || 0,
                    completion_tokens: chunk.usage.completion_tokens || 0,
                    total_tokens: chunk.usage.total_tokens || 0,
                }
                : undefined,
        };
    }
    /**
     * Map Azure AI Foundry response to HALO response format
     */
    mapResponse(response) {
        return {
            id: response.id || "",
            object: "chat.completion",
            created: response.created || Math.floor(Date.now() / 1000),
            model: response.model || "",
            choices: (response.choices || []).map((choice) => ({
                index: choice.index || 0,
                message: {
                    role: choice.message.role,
                    content: choice.message.content,
                    tool_calls: choice.message.tool_calls,
                },
                finish_reason: choice.finish_reason || null,
                logprobs: choice.logprobs || null,
            })),
            usage: response.usage
                ? {
                    prompt_tokens: response.usage.prompt_tokens || 0,
                    completion_tokens: response.usage.completion_tokens || 0,
                    total_tokens: response.usage.total_tokens || 0,
                }
                : undefined,
        };
    }
    /**
     * Map Azure AI Foundry errors to HALO error format
     */
    mapError(error) {
        if (error.response?.data?.error) {
            const foundryError = error.response.data.error;
            return new Error(`Azure AI Foundry Error: ${foundryError.message || error.message} (Code: ${foundryError.code || "unknown"})`);
        }
        return error instanceof Error ? error : new Error(String(error));
    }
}
exports.AzureFoundryAdapter = AzureFoundryAdapter;
//# sourceMappingURL=azureFoundryAdapter.js.map