"use strict";
/**
 * Provider Adapters Export
 *
 * Central export point for all provider adapters and utilities
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.describeResolution = exports.applyResolvedModelSettings = exports.resolveModel = exports.isValidTaskProfile = exports.getTaskProfileNames = exports.getTaskProfile = exports.TASK_PROFILES = exports.getModelsForProvider = exports.hasCapability = exports.getModelCapabilities = exports.MODEL_REGISTRY = exports.AzureFoundryAdapter = exports.OpenAIAdapter = exports.AzureOpenAIAdapter = void 0;
exports.getProviderAdapter = getProviderAdapter;
var azureOpenAIAdapter_1 = require("./azureOpenAIAdapter");
Object.defineProperty(exports, "AzureOpenAIAdapter", { enumerable: true, get: function () { return azureOpenAIAdapter_1.AzureOpenAIAdapter; } });
var openaiAdapter_1 = require("./openaiAdapter");
Object.defineProperty(exports, "OpenAIAdapter", { enumerable: true, get: function () { return openaiAdapter_1.OpenAIAdapter; } });
var azureFoundryAdapter_1 = require("./azureFoundryAdapter");
Object.defineProperty(exports, "AzureFoundryAdapter", { enumerable: true, get: function () { return azureFoundryAdapter_1.AzureFoundryAdapter; } });
var modelRegistry_1 = require("./modelRegistry");
Object.defineProperty(exports, "MODEL_REGISTRY", { enumerable: true, get: function () { return modelRegistry_1.MODEL_REGISTRY; } });
Object.defineProperty(exports, "getModelCapabilities", { enumerable: true, get: function () { return modelRegistry_1.getModelCapabilities; } });
Object.defineProperty(exports, "hasCapability", { enumerable: true, get: function () { return modelRegistry_1.hasCapability; } });
Object.defineProperty(exports, "getModelsForProvider", { enumerable: true, get: function () { return modelRegistry_1.getModelsForProvider; } });
// Task profiles and model selection
var taskProfiles_1 = require("./taskProfiles");
Object.defineProperty(exports, "TASK_PROFILES", { enumerable: true, get: function () { return taskProfiles_1.TASK_PROFILES; } });
Object.defineProperty(exports, "getTaskProfile", { enumerable: true, get: function () { return taskProfiles_1.getTaskProfile; } });
Object.defineProperty(exports, "getTaskProfileNames", { enumerable: true, get: function () { return taskProfiles_1.getTaskProfileNames; } });
Object.defineProperty(exports, "isValidTaskProfile", { enumerable: true, get: function () { return taskProfiles_1.isValidTaskProfile; } });
var modelSelector_1 = require("./modelSelector");
Object.defineProperty(exports, "resolveModel", { enumerable: true, get: function () { return modelSelector_1.resolveModel; } });
Object.defineProperty(exports, "applyResolvedModelSettings", { enumerable: true, get: function () { return modelSelector_1.applyResolvedModelSettings; } });
Object.defineProperty(exports, "describeResolution", { enumerable: true, get: function () { return modelSelector_1.describeResolution; } });
const azureOpenAIAdapter_2 = require("./azureOpenAIAdapter");
const openaiAdapter_2 = require("./openaiAdapter");
const azureFoundryAdapter_2 = require("./azureFoundryAdapter");
/**
 * Get provider adapter by name
 */
function getProviderAdapter(provider) {
    switch (provider) {
        case "azure-openai":
            return new azureOpenAIAdapter_2.AzureOpenAIAdapter();
        case "openai":
            return new openaiAdapter_2.OpenAIAdapter();
        case "azure-ai-foundry":
            return new azureFoundryAdapter_2.AzureFoundryAdapter();
        default:
            return null;
    }
}
//# sourceMappingURL=index.js.map