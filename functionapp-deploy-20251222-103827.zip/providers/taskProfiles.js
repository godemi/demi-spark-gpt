"use strict";
/**
 * Task Profile System
 *
 * Defines task profiles that map to optimal model configurations,
 * enabling users to select models by task type rather than model name.
 *
 * Example usage:
 *   { task_profile: "fast", messages: [...] }  // Uses gpt-5-nano with no reasoning
 *   { task_profile: "reasoning", messages: [...] }  // Uses gpt-5.2 with high reasoning
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TASK_PROFILES = void 0;
exports.getTaskProfile = getTaskProfile;
exports.getTaskProfileNames = getTaskProfileNames;
exports.isValidTaskProfile = isValidTaskProfile;
/**
 * Task profiles mapping
 *
 * Each profile defines the optimal model and settings for a specific use case.
 */
exports.TASK_PROFILES = {
    /**
     * Fast profile - optimized for speed and low latency
     * Use cases: Intent detection, quick decisions, simple classifications
     */
    fast: {
        name: "fast",
        description: "Quick responses for intent detection, simple decisions",
        model: "gpt-5-nano",
        reasoning_effort: "none",
    },
    /**
     * Balanced profile - good quality/speed trade-off
     * Use cases: General purpose tasks, moderate complexity
     */
    balanced: {
        name: "balanced",
        description: "Good quality/speed trade-off for general tasks",
        model: "gpt-5-nano",
        reasoning_effort: "medium",
    },
    /**
     * Reasoning profile - optimized for complex analysis
     * Use cases: Multi-step problems, analytical tasks, code generation
     */
    reasoning: {
        name: "reasoning",
        description: "Complex analysis, multi-step problem solving",
        model: "gpt-5.2",
        reasoning_effort: "high",
    },
    /**
     * Deep reasoning profile - maximum reasoning capability
     * Use cases: Research-level tasks, complex reasoning chains
     */
    deep_reasoning: {
        name: "deep_reasoning",
        description: "Maximum reasoning for research-level tasks",
        model: "gpt-5.2",
        reasoning_effort: "xhigh",
    },
    /**
     * Creative profile - optimized for creative tasks
     * Use cases: Creative writing, brainstorming, idea generation
     */
    creative: {
        name: "creative",
        description: "Creative writing, brainstorming, idea generation",
        model: "gpt-5.2",
        reasoning_effort: "medium",
        temperature: 0.9,
    },
    /**
     * Cost effective profile - budget-conscious option
     * Use cases: High-volume simple tasks, basic completions
     */
    cost_effective: {
        name: "cost_effective",
        description: "Budget-conscious for high-volume simple tasks",
        model: "gpt-5-nano",
        reasoning_effort: "low",
    },
};
/**
 * Get a task profile by name
 */
function getTaskProfile(name) {
    return exports.TASK_PROFILES[name] || null;
}
/**
 * Get all available task profile names
 */
function getTaskProfileNames() {
    return Object.keys(exports.TASK_PROFILES);
}
/**
 * Check if a task profile exists
 */
function isValidTaskProfile(name) {
    return name in exports.TASK_PROFILES;
}
//# sourceMappingURL=taskProfiles.js.map