#!/usr/bin/env ts-node
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const fs_1 = __importDefault(require("fs"));
const inquirer_1 = __importDefault(require("inquirer"));
const path_1 = __importDefault(require("path"));
const semver_1 = __importDefault(require("semver"));
const exec = (cmd) => {
    const result = (0, child_process_1.spawnSync)(cmd, {
        encoding: "utf8",
        stdio: "inherit",
        shell: true,
    });
    if (result.error)
        throw result.error;
    if (result.status !== 0)
        throw new Error(`Command failed: ${cmd}`);
    return result.stdout ? result.stdout.trim() : "";
};
const getLatestTag = () => {
    try {
        const tags = exec("git tag")
            .split("\n")
            .filter(t => /^v?\d+\.\d+\.\d+$/.test(t));
        return tags.sort((a, b) => semver_1.default.rcompare(semver_1.default.coerce(a), semver_1.default.coerce(b)))[0] || null;
    }
    catch {
        return null;
    }
};
const getLatestSnapshots = () => {
    try {
        const tags = exec("git tag")
            .split("\n")
            .filter(t => /-beta\.\d+$/.test(t));
        return tags.sort((a, b) => semver_1.default.rcompare(semver_1.default.coerce(a), semver_1.default.coerce(b))).slice(0, 5);
    }
    catch {
        return [];
    }
};
const getPackageVersion = () => {
    const file = path_1.default.resolve("package.json");
    if (!fs_1.default.existsSync(file))
        return null;
    const pkg = JSON.parse(fs_1.default.readFileSync(file, "utf8"));
    return pkg.version;
};
(async () => {
    const version = getPackageVersion();
    const tag = getLatestTag();
    const snapshots = getLatestSnapshots();
    console.log(`📦 Current version: ${version}`);
    console.log(`🏷️  Latest version tag: ${tag}`);
    if (snapshots.length > 0) {
        console.log("📦 Latest beta tags:");
        snapshots.forEach(tag => console.log(`  - ${tag}`));
    }
    const { action } = await inquirer_1.default.prompt([
        {
            type: "list",
            name: "action",
            message: "What do you want to do?",
            choices: [
                { name: "Create Changeset", value: "changeset" },
                { name: "Apply Version Bump", value: "bump" },
                { name: "Publish Snapshot (beta)", value: "snapshot" },
                { name: "Publish Final Release", value: "publish" },
                { name: "Exit", value: "exit" },
            ],
        },
    ]);
    if (action === "changeset") {
        exec(`pnpm changeset`);
    }
    if (action === "bump") {
        exec(`pnpm changeset version`);
    }
    if (action === "snapshot") {
        const { label } = await inquirer_1.default.prompt([
            {
                type: "input",
                name: "label",
                message: "Snapshot label (e.g. beta, canary)",
                default: "beta",
            },
        ]);
        exec(`pnpm changeset version --snapshot ${label}`);
        console.log(`⚠️ Skipping publish step for snapshot '${label}' (private package)`);
    }
    if (action === "publish") {
        console.log("⚠️ Skipping final publish (private package)");
    }
    if (action === "exit") {
        console.log("👋 Exiting...");
    }
})();
//# sourceMappingURL=release.js.map