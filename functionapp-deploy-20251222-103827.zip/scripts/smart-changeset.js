#!/usr/bin/env ts-node
"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const child_process_1 = require("child_process");
const fs_1 = __importDefault(require("fs"));
const inquirer_1 = __importDefault(require("inquirer"));
const path_1 = __importDefault(require("path"));
// Get changed files since the last Git tag
function getChangedFiles() {
    try {
        const lastTag = (0, child_process_1.execSync)("git describe --tags --abbrev=0", { encoding: "utf-8" }).trim();
        const output = (0, child_process_1.execSync)(`git diff --name-only ${lastTag}`, { encoding: "utf-8" });
        return output.split("\n").filter(Boolean);
    }
    catch (e) {
        console.warn("⚠️ No tags found. Checking full history.");
        const output = (0, child_process_1.execSync)("git ls-files", { encoding: "utf-8" });
        return output.split("\n").filter(Boolean);
    }
}
// Create a changeset file
function createChangesetFile(impact, summary, pkgName) {
    const slug = `${Math.random().toString(36).substring(2, 8)}-${Math.random()
        .toString(36)
        .substring(2, 8)}`;
    const content = `---
"${pkgName}": ${impact}
---

${summary}
`;
    const dir = path_1.default.join(process.cwd(), ".changeset");
    if (!fs_1.default.existsSync(dir))
        fs_1.default.mkdirSync(dir);
    const file = path_1.default.join(dir, `${slug}.md`);
    fs_1.default.writeFileSync(file, content);
    console.log(`✅ Created: .changeset/${slug}.md`);
    return file;
}
async function run() {
    const changedFiles = getChangedFiles();
    if (changedFiles.length === 0) {
        console.log("✅ No changed files since last tag.");
        return;
    }
    console.log("📂 Files changed since last tag:\n");
    changedFiles.forEach(f => console.log("  •", f));
    console.log();
    const pkg = JSON.parse(fs_1.default.readFileSync("package.json", "utf-8")).name;
    const { impact, summary, openFile } = await inquirer_1.default.prompt([
        {
            type: "list",
            name: "impact",
            message: `What type of version bump for ${pkg}?`,
            choices: ["patch", "minor", "major"],
            default: "patch",
        },
        {
            type: "input",
            name: "summary",
            message: "Write a summary for the changelog:",
        },
        {
            type: "confirm",
            name: "openFile",
            message: "Open the changeset file in your editor now?",
            default: false,
        },
    ]);
    const filePath = createChangesetFile(impact, summary, pkg);
    if (openFile) {
        (0, child_process_1.exec)(`open "${filePath}"`);
    }
}
run();
//# sourceMappingURL=smart-changeset.js.map