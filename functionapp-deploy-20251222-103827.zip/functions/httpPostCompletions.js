"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const postCompletionsHandler_1 = require("../handlers/postCompletionsHandler");
/**
 * Azure Function endpoint definition for POST /completions
 * Configures the HTTP endpoint for chat completions requests
 *
 * @endpoint POST /completions
 * @auth function-level authentication required
 * @handler postCompletionsHandler - Processes chat completion requests
 * @description
 * Main endpoint for chat completions:
 * - Accepts POST requests with completion parameters
 * - Validates input parameters
 * - Processes requests through Azure OpenAI
 * - Returns completion responses or handles errors
 */
functions_1.app.http("completions", {
    methods: ["POST"], // Only allow POST requests
    authLevel: "function", // Requires function-level authentication
    handler: postCompletionsHandler_1.postCompletionsHandler, // Links to the handler implementation
});
//# sourceMappingURL=httpPostCompletions.js.map