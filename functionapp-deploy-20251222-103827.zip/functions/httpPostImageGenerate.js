"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const imageGenerateHandler_1 = require("../handlers/imageGenerateHandler");
/**
 * Azure Function endpoint definition for POST /v1/images/generations
 * Image generation endpoint (DALL-E, etc.)
 */
functions_1.app.http("imageGenerate", {
    methods: ["POST", "OPTIONS"],
    route: "v1/images/generations",
    authLevel: "function",
    handler: imageGenerateHandler_1.imageGenerateHandler,
});
//# sourceMappingURL=httpPostImageGenerate.js.map