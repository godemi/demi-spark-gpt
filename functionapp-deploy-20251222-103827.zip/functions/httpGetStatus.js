"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const getStatusHandler_1 = require("../handlers/getStatusHandler");
/**
 * Azure Function endpoint definition for GET /status
 * Configures the HTTP endpoint for checking API and OpenAI service status
 *
 * @endpoint GET /status
 * @auth function-level authentication required
 * @handler getStatusHandler - Checks availability of the API and OpenAI service
 */
functions_1.app.http("status", {
    methods: ["GET"], // Only allow GET requests
    authLevel: "function", // Requires function-level authentication
    handler: getStatusHandler_1.getStatusHandler, // Links to the handler implementation
});
//# sourceMappingURL=httpGetStatus.js.map