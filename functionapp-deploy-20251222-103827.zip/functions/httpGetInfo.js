"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const getInfoHandler_1 = require("../handlers/getInfoHandler");
/**
 * Azure Function endpoint definition for GET /info
 * Configures the HTTP endpoint for retrieving API documentation
 *
 * @endpoint GET /info
 * @auth function-level authentication required
 * @handler getInfoHandler - Processes the request and returns API documentation
 */
functions_1.app.http("info", {
    methods: ["GET"], // Only allow GET requests
    authLevel: "function", // Requires function-level authentication
    handler: getInfoHandler_1.getInfoHandler, // Links to the handler implementation
});
//# sourceMappingURL=httpGetInfo.js.map