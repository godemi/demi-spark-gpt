"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const chatCompletionsHandler_1 = require("../handlers/chatCompletionsHandler");
/**
 * Azure Function endpoint definition for POST /v1/chat/completions
 * Main HALO layer endpoint for chat completions
 */
functions_1.app.http("chatCompletions", {
    methods: ["POST", "OPTIONS"],
    route: "v1/chat/completions",
    authLevel: "function",
    handler: chatCompletionsHandler_1.chatCompletionsHandler,
});
//# sourceMappingURL=httpPostChatCompletions.js.map