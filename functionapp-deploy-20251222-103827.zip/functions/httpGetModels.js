"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const functions_1 = require("@azure/functions");
const listModelsHandler_1 = require("../handlers/listModelsHandler");
/**
 * Azure Function endpoint definition for GET /v1/models
 * Returns list of available models with capabilities
 */
functions_1.app.http("listModels", {
    methods: ["GET"],
    route: "v1/models",
    authLevel: "function",
    handler: listModelsHandler_1.listModelsHandler,
});
//# sourceMappingURL=httpGetModels.js.map