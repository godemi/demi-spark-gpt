"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.telemetry = exports.HALOTelemetry = void 0;
const appInsights = __importStar(require("applicationinsights"));
/**
 * HALO Telemetry - Application Insights integration
 *
 * Tracks requests, metrics, and errors for observability
 */
class HALOTelemetry {
    client = null;
    initialized = false;
    constructor() {
        // Initialize Application Insights if connection string is available
        const connectionString = process.env.APPLICATIONINSIGHTS_CONNECTION_STRING;
        if (connectionString) {
            appInsights.setup(connectionString).start();
            this.client = appInsights.defaultClient;
            this.initialized = true;
        }
    }
    /**
     * Track a chat completion request
     */
    trackRequest(data) {
        if (!this.initialized || !this.client) {
            // Fallback to console logging if App Insights not configured
            console.log("Telemetry:", JSON.stringify(data));
            return;
        }
        // Track custom event
        this.client.trackEvent({
            name: "ChatCompletion",
            properties: {
                request_id: data.requestId,
                model: data.model,
                provider: data.provider,
                streaming: String(data.streaming),
                success: String(data.success),
                error_code: data.errorCode || "",
            },
            measurements: {
                latency_ms: data.latencyMs,
                prompt_tokens: data.promptTokens,
                completion_tokens: data.completionTokens,
                reasoning_tokens: data.reasoningTokens || 0,
                attachment_count: data.attachmentCount,
            },
        });
        // Track dependency (provider call)
        this.client.trackDependency({
            name: `${data.provider}-${data.model}`,
            data: `Chat completion request`,
            duration: data.latencyMs,
            success: data.success,
            resultCode: data.success ? "200" : data.errorCode || "500",
            dependencyTypeName: "HTTP",
        });
        // Track metrics
        this.client.trackMetric({
            name: "ChatCompletion.Latency",
            value: data.latencyMs,
        });
        this.client.trackMetric({
            name: "ChatCompletion.Tokens.Total",
            value: data.promptTokens + data.completionTokens,
        });
    }
    /**
     * Track an error
     */
    trackError(error, requestId, context) {
        if (!this.initialized || !this.client) {
            console.error("Error:", error);
            return;
        }
        this.client.trackException({
            exception: error,
            properties: {
                request_id: requestId,
            },
        });
    }
    /**
     * Track custom metric
     */
    trackMetric(name, value, properties) {
        if (!this.initialized || !this.client) {
            return;
        }
        this.client.trackMetric({
            name,
            value,
            properties,
        });
    }
    /**
     * Flush telemetry (call before function exit)
     */
    flush() {
        if (this.initialized && this.client) {
            this.client.flush();
        }
    }
}
exports.HALOTelemetry = HALOTelemetry;
// Singleton instance
exports.telemetry = new HALOTelemetry();
//# sourceMappingURL=telemetry.js.map